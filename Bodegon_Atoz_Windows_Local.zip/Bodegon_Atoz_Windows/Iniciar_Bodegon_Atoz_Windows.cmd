@echo off
title Bodegon y Market Ato'z - Sistema Administrativo Local
if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" (
  start "" "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --app="%~dp0Bodegon_Atoz_App_Local.html" --window-size=1440,900
  exit
)
if exist "C:\Program Files\Microsoft\Edge\Application\msedge.exe" (
  start "" "C:\Program Files\Microsoft\Edge\Application\msedge.exe" --app="%~dp0Bodegon_Atoz_App_Local.html" --window-size=1440,900
  exit
)
start "" "%~dp0Bodegon_Atoz_App_Local.html"
